---
name: a2ui-component
description: Agregar o modificar un componente del catálogo A2UI de este proyecto. Úsala cuando el agente necesite un tipo de UI que no existe (gráfica, formulario, comparador), cuando el validador rechace un componente, o cuando el frontend pida un contrato nuevo.
---

# Agregar un componente al catálogo

El catálogo es la fuente única de verdad: alimenta el prompt del agente, el
validador y el frontend. Agregar un componente es **un archivo**, pero hay que
cerrar el circuito o el agente pedirá algo que nadie sabe dibujar.

## Pasos

### 1. Definirlo en `src/harness/a2ui/catalog.py`
```python
"ComparadorTasas": {
    "doc": "Compara 2-4 productos por tasa y pago. Úsalo cuando la persona duda entre opciones.",
    "props": {
        "items": {"type": "objectList", "required": True,
                  "keys": ["id", "titulo", "tasa", "pago", "destacado"]},
        "value": {"type": "binding", "required": True},
        "action": {"type": "action"},
    },
},
```
Tipos válidos: `string`, `number`, `boolean`, `enum` (+`values`), `componentId`,
`componentIds`, `objectList` (+`keys`), `binding`, `action`.

**El `doc` es prompt, no comentario.** Escribe *cuándo* usarlo, no qué es.
Una línea, orientada a la intención del usuario.

### 2. Verificar que el validador lo acepta
No hay que tocar `composer.py` si usaste tipos existentes: `_coerce_prop` ya los
cubre. Si inventas un tipo nuevo, agrégalo ahí **y** añade un test.

### 3. Test en `tests/test_composer.py`
Mínimo dos: uno que compile bien, y uno con una prop inválida que caiga al default
o produzca error. Sin red, sin API key.

### 4. Avisar al frontend
El componente aparece solo en `GET /a2ui/catalog.json`. Confirma que el renderer
lo implementa antes de que el agente lo empiece a pedir; si no, la pantalla
renderiza incompleta.

### 5. Revisar el presupuesto
Cada componente suma tokens al `catalog_prompt_digest()`. Si el catálogo pasa de
~18 componentes, evalúa dividirlo por dominio en lugar de crecerlo.

## Checklist
- [ ] `doc` explica cuándo usarlo, en una línea
- [ ] props tipadas, `required` y `default` correctos
- [ ] al menos un componente accionable sigue siendo posible en la pantalla
- [ ] 2 tests en `test_composer.py` pasan
- [ ] el frontend lo implementa (o está avisado)

## Anti-patrones
- Componentes que solo muestran texto: usa `Text` con `variant`.
- Props libres tipo `style` u `html`: A2UI es declarativo justamente para no
  ejecutar código del agente. No abras ese hoyo.
- Un componente por caso de uso ("TarjetaReestructura12Meses"): el catálogo se
  vuelve el producto. Prefiere componentes componibles.
