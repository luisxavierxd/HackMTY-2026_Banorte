---
name: llm-provider
description: Agregar, cambiar o depurar el proveedor de modelo del harness (Gemini, Anthropic, Claude Code, Antigravity). Úsala cuando haya que soportar un modelo nuevo, cuando un perfil falle al arrancar, o cuando el ciclo se rompa después de cambiar LLM_PROVIDER.
---

# Proveedores de modelo

**El proveedor es un flag de código, no una opción del usuario.** Se fija en
`PROVIDER_PROFILES` (`src/harness/config.py`) y se elige con `LLM_PROVIDER`.
Nada en el WebSocket, los headers o la sesión puede cambiarlo en caliente.
Si te piden "que el usuario elija el modelo", la respuesta es no: rompe la
reproducibilidad de la demo y el control de costo.

## Perfiles actuales
```
gemini       API Gemini (Google AI Studio)   · function calling nativo · GOOGLE_API_KEY
anthropic    API Messages de Anthropic       · function calling nativo · ANTHROPIC_API_KEY
claude_code  CLI `claude` headless           · tool calling por prompt · sin API key
antigravity  CLI `agy` headless              · tool calling por prompt · sin API key
hybrid       razona con API, compone con CLI
fake         sin modelo; MCP + validación + A2UI reales
```
`make providers` los lista con lo que requiere cada uno.

## Agregar un proveedor nuevo

### 1. Implementar el contrato
`src/harness/providers/<nombre>.py`, una sola operación:

```python
class MiProvider:
    name = "mi_provider"
    native_tools = True            # False si no expone function calling
    def __init__(self, api_key: str, model: str): ...
    async def complete(self, *, system, messages, tools=None,
                       json_mode=False, temperature=0.2) -> Completion: ...
```

Lo que tu archivo debe absorber (y no filtrar al ciclo):
- **Roles**: el ciclo usa `user` / `assistant`. Gemini dice `model`.
- **Resultados de herramienta**: en Gemini son `function_response` en un turno
  `user`; en Anthropic son bloques `tool_result` con `tool_use_id`.
- **Esquemas**: Anthropic acepta JSON Schema crudo; Gemini necesita
  `sanitize_schema()`. Si el tuyo es distinto, la conversión va aquí.
- **JSON estricto**: Gemini tiene `response_mime_type`; Anthropic se resuelve
  prellenando la respuesta con `{`. Si el tuyo no tiene ninguno, deja
  `json_mode` como instrucción de prompt y confía en la reparación del composer.

### 2. Registrarlo
Rama en `build_provider()` (`providers/__init__.py`) + entrada en
`PROVIDER_PROFILES` con `reasoning`, `ui` y `needs` (la variable de credencial
o `None`).

### 3. Tests en `tests/test_providers.py`
Mínimo: traducción de un historial con `tool_call` + `tool_result`, conversión
del esquema y el perfil en el registro. **Sin red**: se prueban los métodos de
traducción, no la llamada.

### 4. Verificar el ciclo completo
```bash
make test
LLM_PROVIDER=mi_provider make dev
curl -s localhost:8080/readyz | python -m json.tool   # campo "llm"
python scripts/smoke_turn.py "quiero pagar menos intereses"
```

## Los CLIs agénticos (claude_code / antigravity)

Se invocan como subproceso headless:
```
claude -p "<prompt>" --output-format json --bare --append-system-prompt "<sys>"
agy    -p "<prompt>" --output-format json
```
Como no exponen la API de function calling al proceso que los llama,
`native_tools = False` y el ciclo usa **tool calling por prompt**: el manifiesto
va en el system prompt y el CLI responde `{"tool_calls":[...]}` o `{"final":"..."}`.
**El harness sigue ejecutando el MCP.** El modelo decide; nosotros ejecutamos y
auditamos.

`CLI_DELEGATE_MCP=1` pasa `--mcp-config` y deja que el CLI ejecute las tools.
Gana fidelidad agéntica, pierde la traza intermedia — que es justo lo que
alimenta la composición de UI. Default `0` por eso.

## Diagnóstico

| Síntoma | Causa | Qué hacer |
|---|---|---|
| `SystemExit: 'claude' no está en el PATH` | CLI no instalado | instalarlo o cambiar el perfil |
| 400 al mandar tools (Gemini) | esquema no soportado | `mcpx/adapter.py` + caso en `test_adapter.py` |
| 400 al mandar tools (Anthropic) | nombre de tool inválido | debe cumplir `^[a-zA-Z0-9_-]{1,128}$`; el namespacing `dominio__tool` ya cumple |
| el CLI devuelve vacío | stdout no-TTY o flag inexistente | correr el `_argv()` a mano en terminal; ajustar el preset |
| el CLI se cuelga | espera confirmación de permisos | `CLI_EXTRA_ARGS=--dangerously-skip-permissions` en entorno aislado |
| JSON inválido en la fase de UI | el proveedor no respeta `json_mode` | el composer ya repara; si persiste, bajar `MAX_COMPONENTS` |

## No hacer
- Meter lógica de negocio o del catálogo en un proveedor: solo traduce.
- Exponer el modelo en la API pública.
- Asumir que todos soportan `temperature`, `system` o streaming: los CLIs no.
