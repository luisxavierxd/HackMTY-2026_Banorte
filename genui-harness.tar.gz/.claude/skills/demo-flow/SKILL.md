---
name: demo-flow
description: Preparar, correr y depurar la demo en vivo del harness. Úsala antes de presentar, cuando la corrida falle, o para verificar que el ciclo completo (intención → UI → acción → nueva UI) funciona de punta a punta.
---

# Correr y depurar la demo

## Preparación (5 minutos antes)
```bash
make reset          # estado limpio: tarjeta con saldo 18,400
make dev            # o docker compose up -d
curl localhost:8080/readyz     # status ok + 10 herramientas
make test                      # 17 en verde
python scripts/smoke_turn.py "Quiero pagar menos intereses de mi tarjeta"
```
Deja `docker compose logs -f harness` visible: los `tool_call` en vivo prueban
que el MCP es real y no un mock.

El guion de la corrida está en `documentacion/DEMO.md`.

## Diagnóstico por síntoma

| Síntoma | Causa probable | Qué hacer |
|---|---|---|
| `readyz` con un MCP `down` | el server no arrancó o la URL cambió | correr `python mcp_servers/<d>/server.py` a mano y leer el stack trace |
| 400 de Gemini al llamar tools | esquema no soportado (anyOf, $ref, tipo raro) | revisar `mcpx/adapter.py`; agregar un caso a `test_adapter.py` |
| `warnings` en el evento `surface` | el modelo pidió props o componentes fuera del catálogo | leer el warning: dice el id y la prop. Ajustar el `doc` del componente |
| pantalla de fallback | la composición falló dos veces | revisar log `composición de UI falló`; casi siempre es JSON cortado → bajar `MAX_COMPONENTS` |
| la UI no cambia al tocar un control | el frontend no manda `{"type":"action"}` | ver `documentacion/INTEGRACION_FRONTEND.md` §4 |
| el saldo no cambia al aplicar | faltó `confirmado: true` | es el diseño: el botón debe llevar `confirm` |
| todo lento (>8 s) | demasiados pasos de tools | bajar `MAX_TOOL_STEPS`; usar Flash en `GEMINI_UI_MODEL` |

## Planes B
- **Sin internet / sin cuota:** `FAKE_LLM=1`. Corre MCP, validación y A2UI reales;
  solo el modelo es simulado. Dilo en voz alta, no lo escondas.
- **Un dominio caído:** el harness sigue con los demás; `readyz` lo muestra.
- **Estado sucio a media demo:** `make reset` en otra terminal, `DELETE /v1/session/{id}`.

## Antes de presentar, verifica el ciclo completo
1. intención → aparece una pantalla con al menos un control accionable
2. tocar el control → **otra** pantalla, no la misma
3. acción confirmada → el estado cambió y se puede consultar después
4. segundo dominio → funciona sin tocar el harness

Si los cuatro pasan, la demo está lista.
