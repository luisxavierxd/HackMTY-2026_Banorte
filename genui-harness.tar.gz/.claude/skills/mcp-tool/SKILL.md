---
name: mcp-tool
description: Agregar una herramienta MCP o un dominio financiero nuevo (inversiones, pagos, seguros, educación financiera). Úsala cuando el agente necesite datos o una acción que hoy no existe, o cuando haya que montar un servidor MCP adicional.
---

# Agregar una tool o un dominio MCP

## Tool nueva en un servidor existente

En `mcp_servers/<dominio>/server.py`:

```python
@mcp.tool()
def simular_aportacion(monto: float, meses: int, rendimiento_anual: float = 0.09) -> dict:
    """Proyecta el saldo de una meta de ahorro con aportaciones mensuales.

    Args:
        monto: aportación mensual.
        meses: horizonte en meses.
        rendimiento_anual: rendimiento anual esperado (decimal).
    """
```

Reglas que no se negocian:
1. **El docstring es la interfaz del modelo.** Primera línea: qué hace y cuándo
   usarla. `Args:` con una línea por argumento. Gemini decide con esto.
2. **Tipos simples**: `float`, `int`, `str`, `bool`, `list[int]`, `dict`.
   Opcionales con default. Nada de modelos pydantic anidados: el sanitizador los
   aplana y pierdes precisión.
3. **Devuelve dict plano y legible**, con las cifras ya redondeadas. Lo que
   devuelvas es lo que verá la fase de composición de UI.
4. **Si muta estado**: parámetro `confirmado: bool = False`; si es `False`,
   regresa `{"aplicado": False, "requiere_confirmacion": True}`. Toda escritura
   pasa por `store.mutate()`.
5. **Nunca lances excepciones** para errores de negocio: devuelve `{"error": "..."}`
   y deja que el agente lo explique en la UI.

## Dominio nuevo (uno de los seis del reto)

1. `mcp_servers/<dominio>/server.py`:
   ```python
   from mcp.server.mcpserver import MCPServer
   mcp = MCPServer("inversiones", version="1.0.0")
   ```
   Copia el bloque `if __name__ == "__main__":` de `credito/server.py`
   (soporta `--http` con `stateless_http=True`).
2. Reusa `mcp_servers/common/store.py` para el estado sintético.
3. Regístralo: entrada en `mcp_servers.json` (HTTP) o en `load_mcp_servers()`
   de `config.py` (stdio, dev).
4. Servicio en `docker-compose.yml` si va por HTTP.
5. `curl localhost:8080/readyz` debe mostrarlo `up` con sus tools namespaceadas
   `inversiones__*`.

**El harness no cambia.** Si te descubres editando `src/harness/` para agregar un
dominio, la lógica está en el lugar equivocado.

## Tests
`tests/test_domain_<dominio>.py`: importa el módulo del servidor directo (sin
levantar MCP) y prueba la aritmética y la regla de confirmación. Ver
`test_domain_credito.py`.

## Verificar
```bash
make test
make demo && curl -s localhost:8080/a2ui/tools | python -m json.tool
```
