# ADR 0002 — El LLM emite un plan; Python emite el protocolo

**Estado:** aceptado · **Fecha:** 2026-09-11

## Contexto
La opción obvia es pedirle a Gemini que emita envelopes A2UI directamente.
En pruebas, un JSON de protocolo largo produce tres fallas recurrentes:
componentes inventados, ids referenciados que no existen y props mal tipadas.
Cualquiera de las tres deja la pantalla en blanco.

## Decisión
El modelo emite un **plan de UI** compacto (lista plana de componentes con props).
`a2ui/composer.py` lo valida contra el catálogo, coerciona enums, poda referencias
rotas y recién entonces emite `createSurface` / `updateDataModel` / `updateComponents`.

## Consecuencias
- El validador produce errores legibles que se devuelven al modelo: un intento de
  reparación converge casi siempre.
- Si aun así falla, `fallback_plan()` garantiza una superficie renderizable. La demo
  nunca se queda en blanco.
- El composer es determinista: se prueba sin red ni API key (7 tests).
- Migrar de A2UI v0.9.1 a v1.0 toca `messages.py` y nada más.
- Costo: una capa de traducción que hay que mantener sincronizada con el catálogo.
