# ADR 0003 — El catálogo de componentes es la fuente única de verdad

**Estado:** aceptado · **Fecha:** 2026-09-11

## Contexto
El catálogo tiene tres consumidores: el prompt del agente, el validador y el
renderer del frontend. Si divergen, el agente pide componentes que nadie sabe
dibujar.

## Decisión
`a2ui/catalog.py` define componentes y props tipadas. De ahí salen:
- `catalog_prompt_digest()` → una línea por componente para el prompt (barato en tokens);
- `COMPONENTS` → el validador;
- `GET /a2ui/catalog.json` → el contrato que el frontend lee al arrancar.

## Consecuencias
- Agregar un componente es editar un archivo (ver skill `a2ui-component`).
- El frontend puede fallar ruidosamente al boot si no implementa algo del catálogo.
- El `catalogId` viaja en `createSurface`: el cliente puede versionar su renderer.
- Riesgo: el catálogo crece y el prompt también. Por eso el digest es compacto y
  `MAX_COMPONENTS` acota la pantalla.
