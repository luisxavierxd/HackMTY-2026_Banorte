# ADR 0001 — Bucle de function calling manual, no MCP nativo del SDK

**Estado:** aceptado · **Fecha:** 2026-09-11

## Contexto
`google-genai` soporta pasar una sesión MCP directo: `tools=[session]`, con
automatic function calling. Son literalmente 5 líneas y funciona.

## Decisión
Deshabilitar `automatic_function_calling` y correr el bucle nosotros, traduciendo
las tools MCP a `FunctionDeclaration` con un sanitizador propio.

## Consecuencias
**A favor**
- Emitimos `tool_call` / `tool_result` al frontend → la demo muestra el trabajo del
  agente en vivo en lugar de una barra de carga.
- Presupuesto duro (`MAX_TOOL_STEPS`): un bucle infinito no se lleva la demo ni la cuota.
- Auditoría: cada llamada queda en el trace y alimenta la fase de UI.
- Multi-servidor con namespacing; el SDK nativo asume una sesión.

**En contra**
- ~120 líneas más que mantener, incluido el sanitizador de esquemas.
- Si Google estabiliza su integración MCP, parte de esto se vuelve redundante.

## Alternativas
- `tools=[session]`: descartado por falta de observabilidad.
- LangGraph / ADK: framework pesado para un hackathon; el valor está en el composer,
  no en el orquestador.
