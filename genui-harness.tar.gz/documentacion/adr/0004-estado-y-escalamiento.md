# ADR 0004 — Estado fuera del proceso, acciones con efecto real

**Estado:** aceptado · **Fecha:** 2026-09-11

## Contexto
La regla 3 del reto pide una interacción que produzca un cambio real. Y la demo
debe poder correr con varias réplicas sin que la conversación se pierda.

## Decisión
- **Sesión** (historia + data model): interfaz `SessionStore` con backends
  `memory` y `redis`, elegido por `SESSION_BACKEND`. El proceso no guarda nada.
- **Dominio**: `mcp_servers/common/store.py` persiste en JSON con lock. Aplicar un
  plan baja el saldo de la tarjeta, recalcula el pago mínimo y genera folio; el
  siguiente turno ve el estado nuevo.
- **Confirmación**: las tools que mutan exigen `confirmado=true`, que solo llega
  desde un `ActionButton` con `confirm`. El modelo no puede mover dinero por su cuenta.

## Consecuencias
- `--scale harness=3` funciona con `SESSION_BACKEND=redis` sin tocar código.
- Los servidores MCP corren `stateless_http=True`: sin sesión pegajosa.
- El JSON con lock no aguanta concurrencia real; es deliberado y está acotado a
  `read()` / `mutate()` para que migrar a Postgres sean dos funciones.
