# Guion de demo (5 minutos)

La demo vale 5% pero la corrida en vivo es el entregable 01. Esto es lo que se enseña.

## Antes de subir al escenario
```bash
make reset                 # estado sintético limpio: saldo 18,400
docker compose up -d       # o: make dev
curl localhost:8080/readyz # {"status":"ok", 10 herramientas}
```
Ten abierta una segunda terminal con `docker compose logs -f harness`: los
`tool_call` en vivo son la mejor prueba de que el MCP existe de verdad.

## El flujo (un problema pequeño, resuelto completo)

1. **"Quiero pagar menos intereses de mi tarjeta."**
   El agente llama `credito__obtener_saldo_tarjeta` y `credito__simular_reestructura`.
   La pantalla se arma sola: MetricCard con el saldo, OptionList con 12/18/24 meses
   (pago, CAT, ahorro contra pagar el mínimo) y un ActionButton.
   → *Di en voz alta:* nadie programó esta pantalla; el agente eligió los componentes.

2. **Tocar "24 meses".**
   El evento regresa al agente con el data model. Vuelve a decidir: ahora muestra la
   tabla de amortización de ese plazo. **La misma intención, otra interfaz.**
   → *Di:* la pantalla no es estática, se rediseña con cada interacción.

3. **"Aplicar plan".**
   Confirmación → `credito__aplicar_plan_reestructura(confirmado=true)`.
   El saldo de la tarjeta baja, se genera folio, se recalcula el pago mínimo.
   → *Di:* la acción ocurrió de verdad. Y lo pruebas:

4. **"¿Cómo quedó mi tarjeta?"**
   Consulta el estado y muestra el saldo nuevo + el plan activo. El cambio persiste.

5. **Cambio de dominio, misma arquitectura:** "¿En qué se me va el dinero?"
   → `banca__gasto_por_categoria`, BarChart. Sin tocar una línea del harness.
   → *Di:* los seis dominios del reto son un archivo más en `mcp_servers/`.

## Cierre técnico (30 s)
- Diagrama de `documentacion/ARQUITECTURA.md`.
- Una frase por trade-off: bucle manual por observabilidad, composer determinista
  porque una alucinación no puede dejar la pantalla en blanco, catálogo como
  fuente única para agente, validador y frontend.
- `make test`: 17 tests sin red.

## Plan B (en orden de degradación)
1. **Se acabó la cuota de Gemini** → `make demo-anthropic` (otra API, mismo ciclo).
2. **No hay API keys** → `make demo-code` o `make demo-agy`: corren con la
   suscripción local de Claude Code o Antigravity. El MCP lo sigue ejecutando el
   harness; solo cambia quién decide. Arranca estos perfiles **antes** de subir al
   escenario: el primer turno de un CLI tarda más.
3. **Sin internet** → `make demo-offline` (perfil `fake`): el pipeline MCP +
   validación + A2UI corre igual. Dilo en voz alta, no lo escondas.

`curl localhost:8080/readyz` muestra el proveedor y modelo activos: úsalo para
probar en vivo que el ciclo no cambió, solo el motor.
- Un servidor MCP caído: `/readyz` lo marca `down` y el harness sigue con el resto.
- UI vacía: el fallback siempre renderiza algo con botón de reintento.
