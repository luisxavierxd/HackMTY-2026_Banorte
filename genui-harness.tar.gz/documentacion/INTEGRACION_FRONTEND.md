# Integración del frontend

El frontend no necesita saber nada de Gemini ni de MCP. Solo tres cosas:
leer el catálogo, abrir el WebSocket, renderizar envelopes A2UI.

## 1. Al arrancar: leer el catálogo

```ts
const catalog = await fetch(`${API}/a2ui/catalog.json`).then(r => r.json());
// catalog.components -> { Column: {props}, MetricCard: {props}, ... }
```

Implementa un renderer por componente. Si el catálogo trae uno que no conoces,
falla ruidosamente en consola (no en silencio) — así se detecta la divergencia.

## 2. Conectar y mandar turnos

```ts
const ws = new WebSocket(`${WS}/ws/${sessionId}`);

ws.onmessage = (e) => {
  const ev = JSON.parse(e.data);
  switch (ev.type) {
    case "tool_call":   setStatus(`Consultando ${ev.name.split("__")[1]}…`); break;
    case "surface":     applyA2UI(ev.a2ui); setSummary(ev.summary);          break;
    case "turn_end":    setStatus(null);                                     break;
    case "error":       toast(ev.message);                                   break;
  }
};

ws.send(JSON.stringify({ type: "user_message", text: input }));
```

## 3. Aplicar los envelopes

```ts
function applyA2UI(messages) {
  for (const msg of messages) {
    if (msg.createSurface)    createSurface(msg.createSurface);              // surfaceId, catalogId
    if (msg.updateDataModel)  setAtPointer(msg.updateDataModel.path, msg.updateDataModel.value);
    if (msg.updateComponents) setComponents(msg.updateComponents.components); // el root es el primero
  }
}
```

Reglas del render:

- Lista **plana**: `Column.children` / `Card.child` son ids, no objetos anidados.
- Una prop puede ser literal (`"$1,690"`) o binding (`{"path": "/plan/selected"}`);
  si es binding, léela del data model y **re-renderiza** cuando cambie.
- El **root es el primer componente** de `components`.

## 4. Cerrar el ciclo

Cuando la persona toca un `ActionButton`, `OptionList` o mueve un `Slider` con
`action`:

```ts
ws.send(JSON.stringify({
  type: "action",
  name: action.event.name,            // "aplicar_plan"
  params: action.event.params,        // { plan_id: "12m" }
  dataModel: { "/plan/selected": "12m" }   // cambios locales que el agente debe ver
}));
```

Eso llega al agente como contexto, dispara la herramienta MCP correspondiente y
regresa una pantalla nueva. Ese es el requisito central del reto: la interacción
**vuelve** al agente.

Si `confirm` viene en el `ActionButton`, muestra el diálogo **antes** de enviar.
El servidor también lo exige (`confirmado=true`), pero la UX se decide en el cliente.

## 5. Para probar sin frontend

```bash
make demo                                  # sin API key
python scripts/smoke_turn.py "quiero pagar menos intereses"
curl -N -X POST localhost:8080/v1/turn -H 'content-type: application/json' \
  -d '{"session_id":"demo","text":"quiero pagar menos intereses"}'
```
