# CLAUDE.md — contexto del proyecto

Harness de UI generativa para el reto Banorte × Tec: **LLM al centro, MCP para
datos y acciones, A2UI para la interfaz**. Este repo es solo backend; el frontend
se integra por WebSocket (ver `documentacion/INTEGRACION_FRONTEND.md`).

## Mapa mental
- `src/harness/a2ui/` — catálogo propio, validador, composer y envelopes A2UI v0.9.1.
  **Es el corazón.** El LLM nunca emite protocolo crudo.
- `src/harness/agent/` — dos fases: razonar con tools MCP, luego componer la UI.
- `src/harness/providers/` — Gemini, Anthropic y CLIs agénticos detrás de un
  contrato de una sola operación. **El proveedor es un flag de código
  (`PROVIDER_PROFILES` en `config.py`), nunca una opción del usuario.**
- `src/harness/mcpx/` — cliente multi-servidor + sanitizador de esquemas JSON→Gemini.
- `mcp_servers/<dominio>/` — un servidor MCP por dominio financiero.

## Reglas al trabajar aquí
1. **Nunca inventar datos financieros en el prompt.** Todo número sale de una tool MCP.
2. Un componente nuevo se agrega en `a2ui/catalog.py` primero (skill `a2ui-component`).
3. Toda tool que muta estado exige `confirmado: bool = False` y devuelve
   `{"aplicado": False, "requiere_confirmacion": True}` si no viene.
4. El composer debe seguir siendo determinista y testeable sin red.
5. Un proveedor solo traduce: cero lógica de negocio, cero catálogo. Si hay que
   tocar el ciclo para soportar un modelo, la abstracción está mal (skill `llm-provider`).
6. SDK de MCP es la **2.x**: `MCPServer` (no `FastMCP`), `mcp.Client`,
   `tool.input_schema` (snake_case). No regresar a la API 1.x.
7. Español de México en prompts y textos de UI; código y nombres en inglés/español
   consistentes con lo que ya existe.

## Comandos
```
make providers    # perfiles disponibles y qué requiere cada uno
make demo-code    # corre con la suscripción local de Claude Code, sin API key
make demo-offline # sin modelo (perfil fake)
make test    # 17 tests, sin red
make reset   # reinicia el estado sintético
curl localhost:8080/readyz
```

## No hacer
- No agregar frameworks de agentes (LangGraph, ADK): el valor está en el composer.
- No meter lógica de dominio en el harness; va en un servidor MCP.
- No publicar `documentacion/` ni `.claude/`: están en `.gitignore`.
